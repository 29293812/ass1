﻿namespace Scheduling
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.algorithmsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roundRobinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multipleQueuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.priorityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtST = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnR = new System.Windows.Forms.Button();
            this.txtPR = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txtPriority = new System.Windows.Forms.TextBox();
            this.lblPriority = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.tlbPanelP3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblP3 = new System.Windows.Forms.Label();
            this.tlbPanelP2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblP2 = new System.Windows.Forms.Label();
            this.tlbPanelP1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblP1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tlbPanelP3.SuspendLayout();
            this.tlbPanelP2.SuspendLayout();
            this.tlbPanelP1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.algorithmsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(708, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // algorithmsToolStripMenuItem
            // 
            this.algorithmsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.roundRobinToolStripMenuItem,
            this.multipleQueuesToolStripMenuItem,
            this.priorityToolStripMenuItem});
            this.algorithmsToolStripMenuItem.Name = "algorithmsToolStripMenuItem";
            this.algorithmsToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.algorithmsToolStripMenuItem.Text = "Algorithms";
            this.algorithmsToolStripMenuItem.Click += new System.EventHandler(this.algorithmsToolStripMenuItem_Click);
            // 
            // roundRobinToolStripMenuItem
            // 
            this.roundRobinToolStripMenuItem.Name = "roundRobinToolStripMenuItem";
            this.roundRobinToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.roundRobinToolStripMenuItem.Text = "Round Robin";
            this.roundRobinToolStripMenuItem.Click += new System.EventHandler(this.roundRobinToolStripMenuItem_Click);
            // 
            // multipleQueuesToolStripMenuItem
            // 
            this.multipleQueuesToolStripMenuItem.Name = "multipleQueuesToolStripMenuItem";
            this.multipleQueuesToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.multipleQueuesToolStripMenuItem.Text = "Multiple Queues";
            this.multipleQueuesToolStripMenuItem.Click += new System.EventHandler(this.multipleQueuesToolStripMenuItem_Click);
            // 
            // priorityToolStripMenuItem
            // 
            this.priorityToolStripMenuItem.Name = "priorityToolStripMenuItem";
            this.priorityToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.priorityToolStripMenuItem.Text = "Priority";
            this.priorityToolStripMenuItem.Click += new System.EventHandler(this.priorityToolStripMenuItem_Click);
            // 
            // txtST
            // 
            this.txtST.Location = new System.Drawing.Point(81, 36);
            this.txtST.Name = "txtST";
            this.txtST.Size = new System.Drawing.Size(100, 20);
            this.txtST.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Duration";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(405, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Processes";
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(573, 72);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(105, 23);
            this.btnR.TabIndex = 17;
            this.btnR.Text = "insert Processes";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.button11_Click);
            // 
            // txtPR
            // 
            this.txtPR.Location = new System.Drawing.Point(474, 39);
            this.txtPR.Name = "txtPR";
            this.txtPR.Size = new System.Drawing.Size(57, 20);
            this.txtPR.TabIndex = 53;
            this.txtPR.TextChanged += new System.EventHandler(this.txtPR_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txtPriority
            // 
            this.txtPriority.Location = new System.Drawing.Point(621, 33);
            this.txtPriority.Name = "txtPriority";
            this.txtPriority.Size = new System.Drawing.Size(57, 20);
            this.txtPriority.TabIndex = 61;
            // 
            // lblPriority
            // 
            this.lblPriority.AutoSize = true;
            this.lblPriority.Location = new System.Drawing.Point(566, 36);
            this.lblPriority.Name = "lblPriority";
            this.lblPriority.Size = new System.Drawing.Size(36, 13);
            this.lblPriority.TabIndex = 60;
            this.lblPriority.Text = "Prority";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.tlbPanelP1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tlbPanelP2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.tlbPanelP3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(15, 135);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(679, 155);
            this.tableLayoutPanel1.TabIndex = 62;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.AutoSize = true;
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.DodgerBlue;
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel6.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tableLayoutPanel6.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel6.ForeColor = System.Drawing.Color.White;
            this.tableLayoutPanel6.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(4, 113);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(46, 15);
            this.tableLayoutPanel6.TabIndex = 79;
            this.tableLayoutPanel6.UseWaitCursor = true;
            this.tableLayoutPanel6.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 11);
            this.label7.TabIndex = 52;
            this.label7.Text = "P3: C";
            this.label7.UseWaitCursor = true;
            this.label7.Visible = false;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel5.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tableLayoutPanel5.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel5.ForeColor = System.Drawing.Color.White;
            this.tableLayoutPanel5.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(4, 91);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(49, 15);
            this.tableLayoutPanel5.TabIndex = 78;
            this.tableLayoutPanel5.UseWaitCursor = true;
            this.tableLayoutPanel5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 11);
            this.label6.TabIndex = 51;
            this.label6.Text = "P2 : B";
            this.label6.UseWaitCursor = true;
            this.label6.Visible = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AutoSize = true;
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.Gray;
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel4.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tableLayoutPanel4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel4.ForeColor = System.Drawing.Color.White;
            this.tableLayoutPanel4.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(4, 69);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(48, 15);
            this.tableLayoutPanel4.TabIndex = 77;
            this.tableLayoutPanel4.UseWaitCursor = true;
            this.tableLayoutPanel4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 11);
            this.label5.TabIndex = 50;
            this.label5.Text = "P1 : A";
            this.label5.UseWaitCursor = true;
            this.label5.Visible = false;
            // 
            // tlbPanelP3
            // 
            this.tlbPanelP3.AutoSize = true;
            this.tlbPanelP3.BackColor = System.Drawing.Color.DodgerBlue;
            this.tlbPanelP3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlbPanelP3.ColumnCount = 1;
            this.tlbPanelP3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbPanelP3.Controls.Add(this.lblP3, 0, 0);
            this.tlbPanelP3.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tlbPanelP3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbPanelP3.ForeColor = System.Drawing.Color.White;
            this.tlbPanelP3.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tlbPanelP3.Location = new System.Drawing.Point(4, 47);
            this.tlbPanelP3.Name = "tlbPanelP3";
            this.tlbPanelP3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tlbPanelP3.RowCount = 1;
            this.tlbPanelP3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tlbPanelP3.Size = new System.Drawing.Size(46, 15);
            this.tlbPanelP3.TabIndex = 73;
            this.tlbPanelP3.UseWaitCursor = true;
            this.tlbPanelP3.Visible = false;
            // 
            // lblP3
            // 
            this.lblP3.AutoSize = true;
            this.lblP3.Location = new System.Drawing.Point(5, 2);
            this.lblP3.Name = "lblP3";
            this.lblP3.Size = new System.Drawing.Size(36, 11);
            this.lblP3.TabIndex = 52;
            this.lblP3.Text = "P3: C";
            this.lblP3.UseWaitCursor = true;
            this.lblP3.Visible = false;
            // 
            // tlbPanelP2
            // 
            this.tlbPanelP2.AutoSize = true;
            this.tlbPanelP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.tlbPanelP2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlbPanelP2.ColumnCount = 1;
            this.tlbPanelP2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbPanelP2.Controls.Add(this.lblP2, 0, 0);
            this.tlbPanelP2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tlbPanelP2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbPanelP2.ForeColor = System.Drawing.Color.White;
            this.tlbPanelP2.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tlbPanelP2.Location = new System.Drawing.Point(4, 25);
            this.tlbPanelP2.Name = "tlbPanelP2";
            this.tlbPanelP2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tlbPanelP2.RowCount = 1;
            this.tlbPanelP2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tlbPanelP2.Size = new System.Drawing.Size(49, 15);
            this.tlbPanelP2.TabIndex = 72;
            this.tlbPanelP2.UseWaitCursor = true;
            this.tlbPanelP2.Visible = false;
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(5, 2);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(39, 11);
            this.lblP2.TabIndex = 51;
            this.lblP2.Text = "P2 : B";
            this.lblP2.UseWaitCursor = true;
            this.lblP2.Visible = false;
            // 
            // tlbPanelP1
            // 
            this.tlbPanelP1.AutoSize = true;
            this.tlbPanelP1.BackColor = System.Drawing.Color.Gray;
            this.tlbPanelP1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlbPanelP1.ColumnCount = 1;
            this.tlbPanelP1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbPanelP1.Controls.Add(this.lblP1, 0, 0);
            this.tlbPanelP1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.tlbPanelP1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbPanelP1.ForeColor = System.Drawing.Color.White;
            this.tlbPanelP1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tlbPanelP1.Location = new System.Drawing.Point(4, 4);
            this.tlbPanelP1.Name = "tlbPanelP1";
            this.tlbPanelP1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tlbPanelP1.RowCount = 1;
            this.tlbPanelP1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbPanelP1.Size = new System.Drawing.Size(48, 14);
            this.tlbPanelP1.TabIndex = 71;
            this.tlbPanelP1.UseWaitCursor = true;
            this.tlbPanelP1.Visible = false;
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(5, 2);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(38, 10);
            this.lblP1.TabIndex = 50;
            this.lblP1.Text = "P1 : A";
            this.lblP1.UseWaitCursor = true;
            this.lblP1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 635);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.txtPriority);
            this.Controls.Add(this.lblPriority);
            this.Controls.Add(this.txtPR);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtST);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tlbPanelP3.ResumeLayout(false);
            this.tlbPanelP3.PerformLayout();
            this.tlbPanelP2.ResumeLayout(false);
            this.tlbPanelP2.PerformLayout();
            this.tlbPanelP1.ResumeLayout(false);
            this.tlbPanelP1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem algorithmsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roundRobinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multipleQueuesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem priorityToolStripMenuItem;
        private System.Windows.Forms.TextBox txtST;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.TextBox txtPR;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txtPriority;
        private System.Windows.Forms.Label lblPriority;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tlbPanelP1;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.TableLayoutPanel tlbPanelP2;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tlbPanelP3;
        private System.Windows.Forms.Label lblP3;
    }
}

