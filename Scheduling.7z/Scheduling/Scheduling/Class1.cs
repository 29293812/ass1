﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scheduling
{
    class Class1
    {
        public int lengths;
        public int starts;
        public int remains;
        private int priority = 0;
        private int level = 0;
        public Class1(int length,int prioriti, int levels)
        {
            this.priority = prioriti;
            this.lengths = length;
            this.level = levels;


        }
        public int length
        {
            get => default(int);
            set
            {
                int l = lengths;
            }
        }

        public int start
        {
            get => default(int);
            set
            {
                int s = starts;
            }
        }
        public int getpriority()
        {
           
            return priority;
        }
        public int getLevel()
        {
            return level;
        }

        public void setLevel(int level)
        {
            this.level = level;
        }
        public void setPriority(int priority)
        {
            this.priority = priority;
        }
        public int remaining
        {
            get => default(int);
            set
            {
                int r = remains;
            }
        }

        public int Process1(int length, int start, int remains)
        {
            int r = 0;
            /*for (int i = 0; i < length; i++)
            {
               r= Process1(length, start,remains);
            }*/
            return r;
        }

        public int Process2(int length, int start, int remains)
        {
            int r = 0;
           /* for (int i = 0; i < length; i++)
            {
                r = Process1(length, start, remains);
            }*/
            return r;
        }

        public int Process3(int length, int start, int remains)
        {
            int r = 0;
           /* for (int i = 0; i < length; i++)
            {
                r = Process1(length, start, remains);
            }*/
            return r;
        }
    }
}
