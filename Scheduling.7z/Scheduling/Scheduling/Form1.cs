﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scheduling
{
    public partial class Form1 : Form
    {
        const int ROWS = 6;
        const int COLS = 1;

        Timer t = new Timer();
        int x, n, awt, atat, i;
        //  int[] p, pp, bt, w;
        int[] pp;
        int progress = 0;


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void processA(int prio)
        {

            int sta = int.Parse(txtST.Text);
            tlbPanelP1.Visible = true;
            for (int i = 0; i <= 1; i++)
            {
                tlbPanelP1.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

            }

            for (int j = 0; j <= sta; j++)
            {

                tlbPanelP1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            }

            for (int i = 0; i < 10; i++)
            {
                if (sta == i)
                {
                    tlbPanelP1.ColumnCount = i;
                    prio = int.Parse(txtPriority.Text);
                }

                tlbPanelP1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                tlbPanelP1.GrowStyle = TableLayoutPanelGrowStyle.AddColumns;
            }

        }
        public void processB(int prio)
        {
            int sta = int.Parse(txtST.Text);
            tlbPanelP2.Visible = true;


            for (int i = 0; i <= 1; i++)
            {
                tlbPanelP2.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            }

            for (int j = 0; j <= sta; j++)
            {

                tlbPanelP2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            }

            for (int i = 0; i < 10; i++)
            {
                if (sta == i)
                {
                    tlbPanelP2.ColumnCount = i;
                    prio = int.Parse(txtPriority.Text);
                }

                tlbPanelP2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                tlbPanelP2.GrowStyle = TableLayoutPanelGrowStyle.AddColumns;

            }

        }
        public void processC(int prio)
        {
            int sta = int.Parse(txtST.Text);

            tlbPanelP3.Visible = true;

            for (int i = 0; i <= 1; i++)
            {
                tlbPanelP3.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            }

            for (int j = 0; j <= sta; j++)
            {

                tlbPanelP3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            }
            for (int i = 0; i < 10; i++)
            {
                if (sta == i)
                {
                    tlbPanelP3.ColumnCount = i;
                    prio = int.Parse(txtPriority.Text);

                }

                tlbPanelP3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                tlbPanelP3.GrowStyle = TableLayoutPanelGrowStyle.AddColumns;

            }
        }


        private void button11_Click(object sender, EventArgs e)
        {
            tableLayoutPanel1.RowCount = ROWS;
            tableLayoutPanel1.ColumnCount = COLS;
            for (int i = 0; i < ROWS; i++)
            {
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            }

            for (int j = 0; j <= COLS; j++)
            {

                tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));

            }




            int pr = int.Parse(txtPriority.Text);

            int start = int.Parse(txtST.Text);
            int p = int.Parse(txtPR.Text);

            if (p == 1)
            {




                lblP1.Visible = true;
                processA(pr);
            }
            else if (p == 2)
            {

                lblP2.Visible = true;

                processB(pr);
            }

            else if (p == 3)
            {


                lblP3.Visible = true;

                processC(pr);
            }

            else
            {

                lblP3.Visible = false;

                lblP1.Visible = false;

                lblP2.Visible = false;
                tableLayoutPanel1.Visible = false;

            }



        }


        public Form1()
        {

            InitializeComponent();
        }

        private void algorithmsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void progressBar3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblP3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void roundRobinToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void priorityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[] prio = new int[10];
            prio[0] = int.Parse(txtPriority.Text);
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < prio.Length; j++)
                {
                    if (prio[j] > prio[i])
                    {


                    }
                }


            }




        }

        private void multipleQueuesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void txtPR_TextChanged(object sender, EventArgs e)
        {

        }


        //class for scheduler
    }
}
